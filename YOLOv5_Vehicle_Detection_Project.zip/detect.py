import torch
import cv2

model = torch.hub.load('ultralytics/yolov5', 'yolov5s')
model.classes = [1, 2, 3, 5]

cap = cv2.VideoCapture('video_input/traffic_video.mp4')
if not cap.isOpened():
    print("Error opening video file")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    results = model(frame)
    annotated = results.render()[0]
    cv2.imshow('YOLOv5 Video Detection', annotated)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
