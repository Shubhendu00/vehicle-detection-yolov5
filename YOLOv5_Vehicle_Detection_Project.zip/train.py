# Placeholder for training script
print("Train your YOLOv5 model here using custom dataset")
