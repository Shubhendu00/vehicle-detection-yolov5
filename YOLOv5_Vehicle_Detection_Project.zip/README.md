# YOLOv5 Vehicle Detection

This project uses YOLOv5 for real-time vehicle detection including cars, buses, bicycles, and motorcycles.

## Structure
- `detect.py` – Run vehicle detection on video
- `train.py` – Script for training on custom dataset
- `dataset/` – Folder containing images and labels
- `video_input/` – Input video for testing
